﻿
namespace TOPGames
{
    partial class FormPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSair = new System.Windows.Forms.Button();
            this.PbUsuarios = new System.Windows.Forms.PictureBox();
            this.pbProdutos = new System.Windows.Forms.PictureBox();
            this.pbVendas = new System.Windows.Forms.PictureBox();
            this.pbMesas = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.cadastroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usúarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clienteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.artigosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.locaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vendaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alugarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.PbUsuarios)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbProdutos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbVendas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMesas)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSair.ForeColor = System.Drawing.Color.White;
            this.btnSair.Location = new System.Drawing.Point(576, 422);
            this.btnSair.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(113, 23);
            this.btnSair.TabIndex = 131;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = false;
            // 
            // PbUsuarios
            // 
            this.PbUsuarios.Location = new System.Drawing.Point(364, 43);
            this.PbUsuarios.Name = "PbUsuarios";
            this.PbUsuarios.Size = new System.Drawing.Size(150, 150);
            this.PbUsuarios.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PbUsuarios.TabIndex = 130;
            this.PbUsuarios.TabStop = false;
            // 
            // pbProdutos
            // 
            this.pbProdutos.Location = new System.Drawing.Point(188, 43);
            this.pbProdutos.Name = "pbProdutos";
            this.pbProdutos.Size = new System.Drawing.Size(150, 150);
            this.pbProdutos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbProdutos.TabIndex = 129;
            this.pbProdutos.TabStop = false;
            // 
            // pbVendas
            // 
            this.pbVendas.Location = new System.Drawing.Point(540, 43);
            this.pbVendas.Name = "pbVendas";
            this.pbVendas.Size = new System.Drawing.Size(150, 150);
            this.pbVendas.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbVendas.TabIndex = 128;
            this.pbVendas.TabStop = false;
            // 
            // pbMesas
            // 
            this.pbMesas.Location = new System.Drawing.Point(12, 43);
            this.pbMesas.Name = "pbMesas";
            this.pbMesas.Size = new System.Drawing.Size(150, 150);
            this.pbMesas.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbMesas.TabIndex = 127;
            this.pbMesas.TabStop = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cadastroToolStripMenuItem,
            this.vendaToolStripMenuItem,
            this.alugarToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(743, 24);
            this.menuStrip1.TabIndex = 132;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // cadastroToolStripMenuItem
            // 
            this.cadastroToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.usúarioToolStripMenuItem,
            this.clienteToolStripMenuItem,
            this.artigosToolStripMenuItem,
            this.locaçãoToolStripMenuItem});
            this.cadastroToolStripMenuItem.Name = "cadastroToolStripMenuItem";
            this.cadastroToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.cadastroToolStripMenuItem.Text = "Cadastro";
            // 
            // usúarioToolStripMenuItem
            // 
            this.usúarioToolStripMenuItem.Name = "usúarioToolStripMenuItem";
            this.usúarioToolStripMenuItem.Size = new System.Drawing.Size(114, 22);
            this.usúarioToolStripMenuItem.Text = "Usuário";
            this.usúarioToolStripMenuItem.Click += new System.EventHandler(this.usúarioToolStripMenuItem_Click);
            // 
            // clienteToolStripMenuItem
            // 
            this.clienteToolStripMenuItem.Name = "clienteToolStripMenuItem";
            this.clienteToolStripMenuItem.Size = new System.Drawing.Size(114, 22);
            this.clienteToolStripMenuItem.Text = "Cliente";
            this.clienteToolStripMenuItem.Click += new System.EventHandler(this.clienteToolStripMenuItem_Click);
            // 
            // artigosToolStripMenuItem
            // 
            this.artigosToolStripMenuItem.Name = "artigosToolStripMenuItem";
            this.artigosToolStripMenuItem.Size = new System.Drawing.Size(114, 22);
            this.artigosToolStripMenuItem.Text = "Artigos";
            this.artigosToolStripMenuItem.Click += new System.EventHandler(this.artigosToolStripMenuItem_Click);
            // 
            // locaçãoToolStripMenuItem
            // 
            this.locaçãoToolStripMenuItem.Name = "locaçãoToolStripMenuItem";
            this.locaçãoToolStripMenuItem.Size = new System.Drawing.Size(114, 22);
            this.locaçãoToolStripMenuItem.Text = "Jogos";
            this.locaçãoToolStripMenuItem.Click += new System.EventHandler(this.locaçãoToolStripMenuItem_Click);
            // 
            // vendaToolStripMenuItem
            // 
            this.vendaToolStripMenuItem.Name = "vendaToolStripMenuItem";
            this.vendaToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.vendaToolStripMenuItem.Text = "Venda";
            this.vendaToolStripMenuItem.Click += new System.EventHandler(this.vendaToolStripMenuItem_Click);
            // 
            // alugarToolStripMenuItem
            // 
            this.alugarToolStripMenuItem.Name = "alugarToolStripMenuItem";
            this.alugarToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.alugarToolStripMenuItem.Text = "Alugar";
            this.alugarToolStripMenuItem.Click += new System.EventHandler(this.alugarToolStripMenuItem_Click);
            // 
            // FormPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(743, 468);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.PbUsuarios);
            this.Controls.Add(this.pbProdutos);
            this.Controls.Add(this.pbVendas);
            this.Controls.Add(this.pbMesas);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormPrincipal";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.PbUsuarios)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbProdutos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbVendas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMesas)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.PictureBox PbUsuarios;
        private System.Windows.Forms.PictureBox pbProdutos;
        private System.Windows.Forms.PictureBox pbVendas;
        private System.Windows.Forms.PictureBox pbMesas;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cadastroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usúarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clienteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem artigosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem locaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vendaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem alugarToolStripMenuItem;
    }
}

